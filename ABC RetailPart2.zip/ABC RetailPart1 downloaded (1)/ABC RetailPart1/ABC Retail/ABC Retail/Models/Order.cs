﻿using Azure;
using Azure.Data.Tables;

namespace ABC_Retail.Models
{
    public class Order : ITableEntity
    {
        public string PartitionKey { get; set; } = "ORDER";
        public string RowKey { get; set; } = Guid.NewGuid().ToString(); // Unique Order ID

        public int CustomerId { get; set; }
        public DateTime OrderDate { get; set; } // Use DateTime for compatibility

        // Optional: Add more fields
        public float TotalAmount { get; set; }
        public string Status { get; set; } = "Pending";

        public DateTimeOffset? Timestamp { get; set; }
        public ETag ETag { get; set; }
    }
}