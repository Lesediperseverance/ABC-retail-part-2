﻿namespace ABC_Retail.Models;
    public class FileItem
    {
        public string Name { get; set; } = "";
        public bool IsDirectory { get; set; }
        public long? Size { get; set; }
        public DateTimeOffset? LastModified { get; set; }
    }

