﻿using ABC_Retail.Models;
using ABC_Retail.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace ABC_Retail.Controllers
{
    public class CustomerController : Controller
    {
        private readonly TableServices _tables;
        private readonly QueueServices _queue;
        private readonly FileSharesServices _files;

        public CustomerController(TableServices tables, QueueServices queue, FileSharesServices files)
        {
            _tables = tables;
            _queue = queue;
            _files = files;
        }

        // GET: Customer
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var data = await _tables.GetCustomersAsync();
            return View(data);
        }

        // GET: Customer/Details/{id}
        public async Task<IActionResult> Details(string id)
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (id == null) return NotFound();

            var customer = await _tables.GetCustomerAsync(id);
            if (customer == null) return NotFound();

            var files = await _files.ListFilesAsync(id);
            ViewBag.Files = files;

            return View(customer);
        }

        // POST: Customer/UploadFile
        [HttpPost]
        public async Task<IActionResult> UploadFile(IFormFile file, string customerId)
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (file != null && file.Length > 0)
            {
                var fileName = $"{customerId}_{Path.GetFileName(file.FileName)}";
                using var stream = file.OpenReadStream();
                await _files.UploadAsync(fileName, stream);
            }

            return RedirectToAction("Details", new { id = customerId });
        }

        // GET: Customer/DownloadFile
        public async Task<IActionResult> DownloadFile(string fileName)
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var stream = await _files.DownloadAsync(fileName);
            return File(stream, "application/octet-stream", fileName);
        }

        // GET: Customer/Create
        public IActionResult Create()
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            return View(new Customer());
        }

        // POST: Customer/Create
        [HttpPost]
        public async Task<IActionResult> Create(Customer model)
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid) return View(model);

            model.OrderDate = DateTime.SpecifyKind(model.OrderDate, DateTimeKind.Utc);

            await _tables.AddCustomerAsync(model);
            await _queue.SendAsync($"New customer created: {model.FirstName} {model.LastName}");

            return RedirectToAction(nameof(Index));
        }

        // GET: Customer/Edit/{id}
        public async Task<IActionResult> Edit(string id)
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (id == null) return NotFound();

            var customer = await _tables.GetCustomerAsync(id);
            if (customer == null) return NotFound();

            return View(customer);
        }

        // POST: Customer/Edit/{id}
        [HttpPost]
        public async Task<IActionResult> Edit(Customer model)
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (!ModelState.IsValid) return View(model);

            model.OrderDate = DateTime.SpecifyKind(model.OrderDate, DateTimeKind.Utc);

            await _tables.UpdateCustomerAsync(model);
            await _queue.SendAsync($"Customer updated: {model.FirstName} {model.LastName}");

            return RedirectToAction(nameof(Index));
        }

        // GET: Customer/Delete/{id}
        public async Task<IActionResult> Delete(string id)
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            if (string.IsNullOrWhiteSpace(id)) return NotFound();

            var customer = await _tables.GetCustomerAsync(id);
            if (customer == null) return NotFound();

            return View(customer);
        }

        // POST: Customer/Delete/{id}
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            if (HttpContext.Session.GetString("Username") == null)
            {
                return RedirectToAction("Login", "Account");
            }

            await _tables.DeleteCustomerAsync(id);
            await _queue.SendAsync($"Customer deleted: {id}");

            return RedirectToAction(nameof(Index));
        }
    }
}