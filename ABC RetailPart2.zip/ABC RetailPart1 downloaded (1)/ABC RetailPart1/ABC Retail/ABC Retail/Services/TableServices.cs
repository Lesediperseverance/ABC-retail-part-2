﻿using Azure;
using Azure.Data.Tables;
using ABC_Retail.Models;

namespace ABC_Retail.Services
{
    public class TableServices
    {
        private readonly TableClient _customerTable;
        private readonly TableClient _productTable;

        public TableServices(IConfiguration configuration)
        {
            string connectionString = configuration["AzureStorage:ConnectionString"];

            var serviceClient = new TableServiceClient(connectionString);

            _customerTable = serviceClient.GetTableClient("Customer");
            _customerTable.CreateIfNotExists();

            _productTable = serviceClient.GetTableClient("Product");
            _productTable.CreateIfNotExists();
        }

        // ----------------------------
        // CUSTOMER METHODS
        // ----------------------------

        public async Task<List<Customer>> GetCustomersAsync()
        {
            var results = new List<Customer>();
            await foreach (var entity in _customerTable.QueryAsync<Customer>(c => c.PartitionKey == "CUSTOMER"))
            {
                results.Add(entity);
            }
            return results;
        }

        public async Task<Customer?> GetCustomerAsync(string rowKey)
        {
            try
            {
                var response = await _customerTable.GetEntityAsync<Customer>("CUSTOMER", rowKey);
                return response.Value;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                return null;
            }
        }

        public async Task AddCustomerAsync(Customer customer)
        {
            // ✅ Ensure OrderDate is marked as UTC
            if (customer.OrderDate.Kind != DateTimeKind.Utc)
            {
                customer.OrderDate = DateTime.SpecifyKind(customer.OrderDate, DateTimeKind.Utc);
            }

            await _customerTable.AddEntityAsync(customer);
        }

        public async Task UpdateCustomerAsync(Customer customer)
        {
            // ✅ Ensure OrderDate is marked as UTC
            if (customer.OrderDate.Kind != DateTimeKind.Utc)
            {
                customer.OrderDate = DateTime.SpecifyKind(customer.OrderDate, DateTimeKind.Utc);
            }

            await _customerTable.UpdateEntityAsync(customer, ETag.All, TableUpdateMode.Replace);
        }

        public async Task DeleteCustomerAsync(string rowKey)
        {
            await _customerTable.DeleteEntityAsync("CUSTOMER", rowKey);
        }

        // ----------------------------
        // PRODUCT METHODS
        // ----------------------------

        public async Task<List<Product>> GetProductsAsync()
        {
            var results = new List<Product>();
            await foreach (var entity in _productTable.QueryAsync<Product>(p => p.PartitionKey == "PRODUCT"))
            {
                results.Add(entity);
            }
            return results;
        }

        public async Task<Product?> GetProductAsync(string rowKey)
        {
            try
            {
                var response = await _productTable.GetEntityAsync<Product>("PRODUCT", rowKey);
                return response.Value;
            }
            catch (RequestFailedException ex) when (ex.Status == 404)
            {
                return null;
            }
        }

        public async Task AddProductAsync(Product product)
        {
            await _productTable.AddEntityAsync(product);
        }

        public async Task UpdateProductAsync(Product product)
        {
            await _productTable.UpdateEntityAsync(product, ETag.All, TableUpdateMode.Replace);
        }

        public async Task DeleteProductAsync(string rowKey)
        {
            await _productTable.DeleteEntityAsync("PRODUCT", rowKey);
        }
    }
}