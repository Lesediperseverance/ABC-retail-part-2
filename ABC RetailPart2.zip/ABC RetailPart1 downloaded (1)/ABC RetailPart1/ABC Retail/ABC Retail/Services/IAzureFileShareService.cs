﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using ABC_Retail.Models;

namespace ABC_Retail.Services
{
    public interface IAzureFileShareService
    {
        Task<IReadOnlyList<FileItem>> ListAsync(string? directory = null);
        Task UploadAsync(IFormFile file, string? directory = null, CancellationToken ct = default);
        Task<Stream> DownloadAsync(string name, string? directory = null);
        Task DeleteAsync(string name, string? directory = null);
        Task CreateDirectoryAsync(string name, string? parentDirectory = null);
        Task<bool> ExistsAsync(string name, string? directory = null);
    }
}